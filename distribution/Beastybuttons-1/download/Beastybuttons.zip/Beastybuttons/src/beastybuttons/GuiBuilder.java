package beastybuttons;

import processing.core.*;

//This instances a fully graphical user interface to build a GUI on the fly while generating an import.beasty file
//this is the third way to create a GUI with BeastyButtons after through code and after writing an import file


//IDEA: have the Viewport on the left and on the right the properties of the selected element

@Experimental
@NotImplementedYet
public class GuiBuilder {
	
	//******VARIABLES******
	private final PApplet REF;
	
	
	
	
	public GuiBuilder(PApplet ref) {
		this.REF = ref;
		PApplet.println("WARNING(BB): GUI BUILDER CLASS IS NOT YET IMPLEMENTED AND SUPPORTED, DO NOT USE IT NOW");
	}
}
