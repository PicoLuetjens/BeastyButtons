package beastybuttons;

enum WidgetMode {
	WIDGET,
	SURFACE
}
